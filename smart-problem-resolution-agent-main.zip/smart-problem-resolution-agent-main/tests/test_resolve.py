"""
Basic tests for the Smart Problem Resolution Agent.
These tests mock the Anthropic API call so they run without a real API key.
"""
import json
from unittest.mock import patch, MagicMock

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def _mock_message_response(category="IT", priority="High"):
    text_block = MagicMock()
    text_block.type = "text"
    text_block.text = json.dumps({
        "category": category,
        "priority": priority,
        "reasoning": "Test reasoning.",
        "recommended_action": "Test action.",
    })
    mock_response = MagicMock()
    mock_response.content = [text_block]
    return mock_response


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_root():
    response = client.get("/")
    assert response.status_code == 200


@patch("app.core.resolver.get_client")
def test_resolve_endpoint_returns_expected_fields(mock_get_client):
    mock_client = MagicMock()
    mock_client.messages.create.return_value = _mock_message_response()
    mock_get_client.return_value = mock_client

    response = client.post(
        "/api/v1/resolve",
        json={"problem_description": "My laptop screen is completely black and won't boot."},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["category"] == "IT"
    assert data["priority"] == "High"
    assert "suggested_contact" in data
    assert "contact_email" in data
    assert "estimated_response_time" in data


def test_resolve_endpoint_rejects_short_input():
    response = client.post("/api/v1/resolve", json={"problem_description": "hi"})
    assert response.status_code == 422
